#!/usr/bin/env bash
# zip current directory except for zip file
zip -r link-sweep.zip . -x link-sweep.zip
